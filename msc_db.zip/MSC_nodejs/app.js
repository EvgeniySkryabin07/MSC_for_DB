const express = require('express');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;

// Middleware для парсинга данных из форм
app.use(express.urlencoded({ extended: true }));

// Конфигурация подключения к MySQL
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '1212',
    database: 'systema_upravleniya_kontentom'
};

// Создаем соединение с БД
const connection = mysql.createConnection(dbConfig);

// Подключаемся к БД
connection.connect((err) => {
    if (err) {
        console.error('Ошибка подключения:', err.message);
    } else {
        console.log('Успешное подключение к БД');
    }
});

// Главная страница с таблицей user
app.get('/', (req, res) => {
    // Получаем данные из таблицы user
    connection.query('SELECT * FROM user', (err, users) => {
        // Формируем таблицу с данными
        let tableHTML = '';
        if (users.length > 0) {
            tableHTML = `
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Last Login</th>
                        <th>Active</th>
                    </tr>
                </thead>
                <tbody>
                    ${users.map(user => `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.username || '-'}</td>
                        <td>${user.email || '-'}</td>
                        <td>${user.phone_number || '-'}</td>
                        <td>${user.last_login ? new Date(user.last_login).toLocaleString('ru-RU') : '-'}</td>
                        <td>${user.is_active === 1 ? 'Да' : 'Нет'}</td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
            <p>Всего записей: ${users.length}</p>
            `;
        } else {
            tableHTML = '<p>Таблица user существует, но пуста</p>';
        }

        // Отправляем HTML страницу
        res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Таблица User</title>
            <meta charset="UTF-8">
        </head>
        <body>
            <h1>Таблица пользователей (user)</h1>
            <p><a href="/login">Перейти на страницу авторизации</a></p>
            ${tableHTML}
        </body>
        </html>
        `);
    });
});

// Страница авторизации
app.get('/login', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Авторизация</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Страница авторизации</h1>
        <p><a href="/">Вернуться к таблице пользователей</a></p>
        
        <form method="POST" action="/login">
            <div>
                <label>Логин:</label>
                <input type="text" name="login" required>
            </div>
            
            <div>
                <label>Пароль:</label>
                <input type="password" name="password" required>
            </div>
            
            <input type="submit" value="Войти">
        </form>
    </body>
    </html>
    `);
});

// Обработка POST запроса авторизации (простая демонстрация)
app.post('/login', (req, res) => {
    const { login, password } = req.body;
    
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Результат авторизации</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Это демонстрация авторизации. Были введены:</h1>
        <p>Логин: ${login}</p>
        <p>Пароль: ${password}</p>
        <p><a href="/login">Назад к авторизации</a></p>
        <p><a href="/">На главную</a></p>
    </body>
    </html>
    `);
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});

// Обработка Ctrl+C для graceful shutdown
process.on('SIGINT', () => {
    console.log('\nОстановка сервера...');
    connection.end();
    process.exit(0);
});