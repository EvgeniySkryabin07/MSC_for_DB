const express = require('express');
const crypto = require('crypto');
const mysql = require('mysql2');
const PORT = 3000;
const cookieParser = require('cookie-parser');
const app = express();

// Middleware должны быть подключены до маршрутов
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Конфигурация подключения к MySQL
const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: '1212',
    database: 'systema_upravleniya_kontentom'
};

// Создаем соединение с БД
const connection = mysql.createConnection(dbConfig);

// Подключаемся к БД
connection.connect((err) => {
    if (err) {
        console.error('Ошибка подключения:', err.message);
    } else {
        console.log('Успешное подключение к БД');
    }
});

// Рекурсивная функция для построения древовидной структуры категорий
function buildCategoryTree(categories, parentId = null, level = 0) {
    let html = '';

    const children = categories.filter(cat => cat.parent_id == parentId); //кароче тупо ищем одинаковые по айди и дальше работаем только с ними
    
    if (children.length > 0) {
        html += '<ul>';
        
        children.forEach(category => {
            const indent = '&nbsp;&nbsp;&nbsp;&nbsp;'.repeat(level); // пробелы вставляем 
            html += `
            <li>
                ${indent} 
                <a href="#${category.slug}">${category.name}</a> 
                ${indent}
            `; 
            
            html += buildCategoryTree(categories, category.id, level + 1);
            
            html += '</li>';
        });
        
        html += '</ul>';
    }
    
    return html;
}

// страница с категориями 
app.get('/categories', async (req, res) => {
    try {
        // Получаем все категории из базы данных
        const categories = await new Promise((resolve, reject) => {
            connection.query('SELECT * FROM categories ORDER BY parent_id, name', (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });
        
        // Строим древовидную структуру
        const treeHTML = buildCategoryTree(categories);
        
        // Таблица всех категорий для сравнения
        let tableHTML = '';
        if (categories.length > 0) {
            tableHTML = `
            <p>Всего категорий: ${categories.length}</p>
            `;
        } else {
            tableHTML = '<p>Таблица categories пуста</p>';
        }
        
        const htmlResponse = `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Категории</title>
            <meta charset="UTF-8">
        </head>
        <body>
            <h1>Древовидная структура категорий</h1>
            
            <p><a href="/">Главная</a> | <a href="/login">Авторизация</a> | <a href="/profile">Профиль</a> | <a href="/categories">Категории</a></p>
            
            <h2>Дерево категорий:</h2>
            ${treeHTML || '<p>Нет категорий для отображения</p>'}
            
            ${tableHTML}
    
        </body>
        </html>
        `;
        
        res.send(htmlResponse);
        
    } catch (error) {
        console.error('Ошибка получения категорий:', error);
        res.status(500).send(`
            <h1>Ошибка сервера</h1>
            <p>${error.message}</p>
            <p><a href="/">Вернуться на главную</a></p>
        `);
    }
});

// Главная страница с таблицей user
app.get('/', (req, res) => {
    connection.query('SELECT * FROM user', (err, users) => {
        let tableHTML = '';
        if (users.length > 0) {
            tableHTML = `
            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Last Login</th>
                        <th>Active</th>
                    </tr>
                </thead>
                <tbody>
                    ${users.map(user => `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.username || '-'}</td>
                        <td>${user.last_login ? new Date(user.last_login).toLocaleString('ru-RU') : '-'}</td>
                        <td>${user.is_active === 1 ? 'Да' : 'Нет'}</td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
            <p>Всего записей: ${users.length}</p>
            `;
        } else {
            tableHTML = '<p>Таблица user пуста</p>';
        }

        res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Таблица User</title>
            <meta charset="UTF-8">
        </head>
        <body>
            <h1>Таблица пользователей</h1>
            <p><a href="/">Главная</a> | <a href="/login">Авторизация</a> | <a href="/profile">Профиль</a> | <a href="/categories">Категории</a></p>
            ${tableHTML}
        </body>
        </html>
        `);
    });
});

// Страница с формой авторизации
app.get('/login', (req, res) => {
    const message = req.query.message || '';
    const messageType = req.query.type || '';
    
    let messageHTML = '';
    if (message) {
        messageHTML = `<p><strong>${message}</strong></p>`;
    }
    
    res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Авторизация</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Форма авторизации</h1>
        <p><a href="/">Главная</a> | <a href="/login">Авторизация</a> | <a href="/profile">Профиль</a> | <a href="/categories">Категории</a></p>
        
        ${messageHTML}
        
        <form method="POST" action="/login">
            <div>
                <label>Логин:</label><br>
                <input type="text" name="login">
            </div>
            <br>
            <div>
                <label>Пароль:</label><br>
                <input type="password" name="password">
            </div>
            <br>
            <input type="submit" value="Войти">
        </form>
    </body>
    </html>
    `);
});

// Роут который принимает данные из формы и возвращает результат на форму
app.post('/login', async (req, res) => {
    const { login, password } = req.body;
    
    try {
        const userQuery = 'SELECT id, username, password FROM user WHERE username = ? AND password = ?';
        
        const users = await new Promise((resolve, reject) => {
            connection.query(userQuery, [login, password], (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });
        
        if (users.length === 0) {
            return res.redirect('/login?message=Ошибка авторизации&type=error');
        }
        
        const user = users[0];
        
        const sessionHash = crypto.randomBytes(16).toString('hex');
        
        const createdAt = new Date();
        const expiresAt = new Date();
        expiresAt.setMinutes(expiresAt.getMinutes() + 10);
        
        const sessionQuery = `
            INSERT INTO sessions 
            (user_id, session_hash, created_at) 
            VALUES (?, ?, ?)
        `;
        
        await new Promise((resolve, reject) => {
            connection.query(
                sessionQuery,
                [user.id, sessionHash, createdAt, expiresAt],
                (err, result) => {
                    if (err) reject(err);
                    else resolve(result);
                }
            );
        });
        
        console.log(`Создана сессия для пользователя ${user.id}`);
        
        res.cookie('session_token', sessionHash, {
            maxAge: 3 * 60 * 1000,
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict'
        });
        
        res.redirect('/profile');
        
    } catch (error) {
        console.error('Ошибка входа:', error);
        res.redirect('/login?message=Ошибка сервера&type=error');
    }
});

// Маршрут для получения профиля пользователя
app.get('/profile', async (req, res) => {
    try {
        const sessionToken = req.cookies?.session_token;
        
        if (!sessionToken) {
            return res.status(401).send(`
                <h1>401 Unauthorized</h1>
                <p>Требуется авторизация</p>
                <p><a href="/login">Перейти к авторизации</a></p>
            `);
        }
        
        const sessionQuery = `
            SELECT s.*, u.username, u.email, u.phone_number
            FROM sessions s
            JOIN user u ON s.user_id = u.id
            WHERE s.session_hash = ? 
        `;
        
        const sessions = await new Promise((resolve, reject) => {
            connection.query(sessionQuery, [sessionToken], (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });
        
        if (sessions.length === 0) {
            res.clearCookie('session_token');
            
            return res.status(401).send(`
                <h1>401 Unauthorized</h1>
                <p>Сессия истекла или недействительна</p>
                <p><a href="/login">Авторизоваться снова</a></p>
            `);
        }
        
        const session = sessions[0];
        
        const userId = session.user_id;
        
        const userQuery = 'SELECT id, username, email, phone_number, last_login FROM user WHERE id = ?';
        const users = await new Promise((resolve, reject) => {
            connection.query(userQuery, [userId], (err, results) => {
                if (err) reject(err);
                else resolve(results);
            });
        });
        
        if (users.length === 0) {
            const deleteSessionQuery = 'DELETE FROM sessions WHERE id = ?';
            await new Promise((resolve, reject) => {
                connection.query(deleteSessionQuery, [session.id], (err, result) => {
                    if (err) reject(err);
                    else resolve(result);
                });
            });
            
            res.clearCookie('session_token');
            return res.status(401).send(`
                <h1>401 Unauthorized</h1>
                <p>Пользователь не найден</p>
                <p><a href="/login">Авторизоваться снова</a></p>
            `);
        }
        
        const user = users[0];
        
        const htmlResponse = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Профиль пользователя</title>
                <meta charset="UTF-8">
            </head>
            <body>
                <h1>Профиль пользователя</h1>
                <p><a href="/">Главная</a> | <a href="/login">Авторизация</a> | <a href="/profile">Профиль</a> | <a href="/categories">Категории</a></p>
                
                <h2>Данные пользователя:</h2>
                <p>Имя пользователя: ${user.username}</p>
                <p>Email: ${user.email || 'Не указан'}</p>
                <p>Номер телефона: ${user.phone_number || 'Не указан'}</p>
                <p>ID пользователя: ${user.id}</p>
                
                <h3>Информация о сессии:</h3>
                <p>ID сессии: ${session.id}</p>
                <p>Токен сессии: ${session.session_hash.substring(0, 16)}...</p>
                <p>Сессия создана: ${new Date(session.created_at).toLocaleString('ru-RU')}</p>
            </body>
            </html>
        `;
        
        res.send(htmlResponse);
        
    } catch (error) {
        console.error('Ошибка получения профиля:', error);
        res.status(500).send('Ошибка сервера');
    }
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});

// Обработка Ctrl+C
process.on('SIGINT', () => {
    console.log('\nОстановка сервера...');
    connection.end();
    process.exit(0);
});