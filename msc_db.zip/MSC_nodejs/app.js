const express = require('express');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;

// Конфигурация подключения к MySQL
const dbConfig = {
    host: 'localhost',
    user: 'root',          // ваш пользователь MySQL
    password: '1212',          // ваш пароль (оставьте пустым если нет пароля)
    database: 'systema_upravleniya_kontentom'       // ваша база данных
};

// Создаем соединение с БД
const connection = mysql.createConnection(dbConfig);

// Подключаемся к БД
connection.connect((err) => {
    if (err) {
        console.error('Ошибка подключения:', err.message);
    }
});

// Единственный маршрут - главная страница с выводом таблицы user
app.get('/', (req, res) => {
    // Получаем данные из таблицы user
    connection.query('SELECT * FROM user', (err, users) => {
        // Формируем таблицу с данными
        let tableHTML = '';
        if (users.length > 0) {
            tableHTML = `
            <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Last Login</th>
                        <th>Active</th>
                    </tr>
                </thead>
                <tbody>
                    ${users.map(user => `
                    <tr>
                        <td>${user.id}</td>
                        <td>${user.username || '-'}</td>
                        <td>${user.email || '-'}</td>
                        <td>${user.phone_number || '-'}</td>
                        <td>${user.last_login ? new Date(user.last_login).toLocaleString('ru-RU') : '-'}</td>
                        <td>${user.is_active === 1 ? 'Да' : 'Нет'}</td>
                    </tr>
                    `).join('')}
                </tbody>
            </table>
            <p><strong>Всего записей:</strong> ${users.length}</p>
            `;
        } else {
            tableHTML = '<p>Таблица user существует, но пуста</p>';
        }

        // Отправляем HTML страницу
        res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Таблица User</title>
            <meta charset="UTF-8">
        </head>
        <body>
            <h1>Таблица пользователей (user)</h1>
            ${tableHTML}
            <hr>
        </body>
        </html>
        `);
    });
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`Сервер запущен`);
});

// Обработка Ctrl+C для graceful shutdown
process.on('SIGINT', () => {
    console.log('\n Остановка сервера...');
    connection.end();
    console.log(' Соединение с БД закрыто');
    process.exit(0);
});